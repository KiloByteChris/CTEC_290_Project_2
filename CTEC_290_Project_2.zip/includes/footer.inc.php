<footer>
	<p>Chris McGuire</p>
	<p>CTEC 290 - API</p>
	<p>Winter 18</p>
</footer>